
nt = size(t,1);
q = zeros(nt,1);

for k = 1:nt
  q(k) = tet_anisotropy(p(t(k,:),:));
end

fprintf('min q = %g\n', min(q));
fprintf('max q = %g\n', max(q));
fprintf('mean q = %g\n', mean(q));

function q = tet_anisotropy(X)
  % X is 4 x 3 array of tet vertex coordinates

  J = [X(2,:)-X(1,:);
       X(3,:)-X(1,:);
       X(4,:)-X(1,:)]';

  s = svd(J);

  q = max(s) / min(s);
end
