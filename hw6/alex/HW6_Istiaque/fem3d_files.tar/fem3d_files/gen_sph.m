hdr;
hold off;


% ref 1: npts=10, ntets=8
% ref 2: npts=35, ntets=64
% ref 3: npts=165, ntets=512
% ref 4: npts=969, ntets=4096
% ref 5: npts=6545, ntets=32768
% ref 6: npts=47905, ntets=262144
% ref 7: npts=366145, ntets=2097152
% ref 8: npts=2862209, ntets=16777216

  % Initial regular tetrahedron on unit sphere

  single_tet=0;

  if single_tet > 0;
     p = [ 1  1  1;
           1 -1 -1;
          -1  1 -1;
          -1 -1  1 ];
     p = p ./ sqrt(sum(p.^2,2));

     t = [1 2 3 4];

  else;

     p = [ ...
        0  0  0;
        1  0  0;
       -1  0  0;
        0  1  0;
        0 -1  0;
        0  0  1;
        0  0 -1 ];

     t = [ ...
       1  2  4  6;
       1  4  3  6;
       1  3  5  6;
       1  5  2  6;

       1  4  2  7;
       1  3  4  7;
       1  5  3  7;
       1  2  5  7 ];

     t = orient_tets(p,t);

  end;

  for r = 1:nref
    [p,t] = refine_tet_mesh(p,t,true);

     p = smooth_all_nodes_project_boundary(p,t,10);

    fprintf('ref %d: npts=%d, ntets=%d\n', r, size(p,1), size(t,1));

    % quick plot of boundary vertices
    E  = size(t,1);
    nb = size(p,1);
    rr = p(:,1).*p(:,1)+p(:,2).*p(:,2)+p(:,3).*p(:,3);
    ib = find(rr>0.999);
    plot3(p(ib,1),p(ib,2),p(ib,3),'k.');
    axis equal; grid on;
    title(['Number of Elements and Points: ' int2str([E,nb]) ],fs,18);

    hold on;
    n30 = min(E-1,30);
    for k=1:2:n30; l=k+1;
      plot3(p(t(k,:),1),p(t(k,:),2),p(t(k,:),3),'r-',lw,2)
      plot3(p(t(l,:),1),p(t(l,:),2),p(t(l,:),3),'b-',lw,2)
    end;
    hold off;
    drawnow; pause(.1);

end


if E<1e6;
   q = zeros(E,1);
   for k = 1:E;
     q(k) = tet_anisotropy(p(t(k,:),:));
   end 
   figure;
   plot([1:E]',q,'r.',ms,14);
end;

