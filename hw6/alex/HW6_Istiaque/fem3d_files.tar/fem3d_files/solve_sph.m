hdr;

nref = 6; gen_sph;

[AL,BL,Q]=abq_tet(p,t); % Build 3D FEM stiffness matrix


Ab = Q'*AL*Q;

nL = 4*E;
nb = size(Ab,1);

xb=p(:,1); yb=p(:,2); zb=p(:,3); rb=sqrt(xb.*xb+yb.*yb+zb.*zb);
ibdry = find(rb>1.0-1e-6);
R = restriction(ibdry,nb);

yL=Q*yb;
fL= yL;
f = R*(Q'*fL);

A = R*Ab*R';

use_cg = 1;

global L
L = ichol(A);
global dA;
dA = 1./diag(A);

t0=tic;
if use_cg > 0;
   tol = 1.e-8; maxit=2000;
   [u, flag, relres, iter, resvec] = pcg(A, f, tol, maxit, @mprec);
else
   u = A \ f;
end;
etime=toc(t0);

ub= R'*u;

iz=find(abs(zb)<0.02);
um=max(max(abs(ub(iz))));

plot3(xb(iz),yb(iz),ub(iz)/um,'b.',ms,12);
axis equal;

E  = size(t,1);
nb = size(p,1);
title(['Number of Elements and Points, time: ' num2str([E,nb,etime]) ],fs,14);

