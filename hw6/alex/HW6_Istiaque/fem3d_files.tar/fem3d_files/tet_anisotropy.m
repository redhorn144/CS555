function q = tet_anisotropy(X)
  % X is 4 x 3 array of tet vertex coordinates

  J = [X(2,:)-X(1,:);
       X(3,:)-X(1,:);
       X(4,:)-X(1,:)]';

  s = svd(J);

  q = max(s) / min(s);
end
