function t = orient_tets(p,t)
  a = p(t(:,1),:);
  b = p(t(:,2),:);
  c = p(t(:,3),:);
  d = p(t(:,4),:);

  vol6 = dot(cross(b-a,c-a,2), d-a, 2);

  bad = find(vol6 < 0);

  % Swap two vertices to flip orientation
  tmp = t(bad,3);
  t(bad,3) = t(bad,4);
  t(bad,4) = tmp;
