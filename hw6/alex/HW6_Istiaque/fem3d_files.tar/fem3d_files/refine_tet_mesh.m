function [pnew,tnew] = refine_tet_mesh(p,t,project_to_sphere)
  if nargin < 3
    project_to_sphere = false;
  end

  nt = size(t,1);
  np = size(p,1);

  % Local edge numbering:
  % 1:12, 2:13, 3:14, 4:23, 5:24, 6:34
  E = [t(:,[1 2]);
       t(:,[1 3]);
       t(:,[1 4]);
       t(:,[2 3]);
       t(:,[2 4]);
       t(:,[3 4])];

  Es = sort(E,2);

  % unique global edges and inverse map
  [Eu,~,ic] = unique(Es,'rows');

  ne = size(Eu,1);
  mid = np + (1:ne)';

  % Create midpoint coordinates
  pmid = 0.5*(p(Eu(:,1),:) + p(Eu(:,2),:));

  % Project midpoints on boundary edges to sphere
  if project_to_sphere
    bedge = boundary_edge_flags(t,Eu);

    rr = sqrt(sum(pmid(bedge,:).^2,2));
    pmid(bedge,:) = pmid(bedge,:) ./ rr;
  end

  pnew = [p; pmid];

  % Reshape inverse map into edge midpoint IDs per tet
  ic = reshape(ic,nt,6);

  m12 = mid(ic(:,1));
  m13 = mid(ic(:,2));
  m14 = mid(ic(:,3));
  m23 = mid(ic(:,4));
  m24 = mid(ic(:,5));
  m34 = mid(ic(:,6));

  v1 = t(:,1); v2 = t(:,2); v3 = t(:,3); v4 = t(:,4);

  % 8-tet refinement pattern
  %
  % Four corner tets:
  T1 = [v1  m12 m13 m14];
  T2 = [m12 v2  m23 m24];
  T3 = [m13 m23 v3  m34];
  T4 = [m14 m24 m34 v4 ];

  % Central octahedron split into four tets along diagonal m12--m34:
  T5 = [m12 m13 m14 m34];
  T6 = [m12 m13 m23 m34];
  T7 = [m12 m23 m24 m34];
  T8 = [m12 m14 m24 m34];

  tnew = [T1; T2; T3; T4; T5; T6; T7; T8];

  % Fix orientations so all tet volumes are positive
  tnew = orient_tets(pnew,tnew);
end

