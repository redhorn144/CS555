function [AL,BL,Q]=abq_tet(p,t) % Build 3D FEM stiffness matrix

nt = size(t,1); 

x12 = p(t(:,1),1) - p(t(:,2),1);
x23 = p(t(:,2),1) - p(t(:,3),1);
x34 = p(t(:,3),1) - p(t(:,4),1);
x41 = p(t(:,4),1) - p(t(:,1),1);

y12 = p(t(:,1),2) - p(t(:,2),2);
y23 = p(t(:,2),2) - p(t(:,3),2);
y34 = p(t(:,3),2) - p(t(:,4),2);
y41 = p(t(:,4),2) - p(t(:,1),2);

z12 = p(t(:,1),3) - p(t(:,2),3);
z23 = p(t(:,2),3) - p(t(:,3),3);
z34 = p(t(:,3),3) - p(t(:,4),3);
z41 = p(t(:,4),3) - p(t(:,1),3);

xy234 = ( x34.*y23 - x23.*y34  );
xy341 = ( x34.*y41 - x41.*y34  );
xy412 = ( x12.*y41 - x41.*y12  );
xy123 = ( x12.*y23 - x23.*y12  );
xz234 = ( x23.*z34 - x34.*z23  );
xz341 = ( x41.*z34 - x34.*z41  );
xz412 = ( x41.*z12 - x12.*z41  );
xz123 = ( x23.*z12 - x12.*z23  );
yz234 = ( y34.*z23 - y23.*z34  );
yz341 = ( y34.*z41 - y41.*z34  );
yz412 = ( y12.*z41 - y41.*z12  );
yz123 = ( y12.*z23 - y23.*z12  );

g(1,1,:) = -(p(t(:,2),1).*yz234 + p(t(:,2),2).*xz234 + p(t(:,2),3).*xy234);
g(2,1,:) = -(p(t(:,3),1).*yz341 + p(t(:,3),2).*xz341 + p(t(:,3),3).*xy341);
g(3,1,:) = -(p(t(:,4),1).*yz412 + p(t(:,4),2).*xz412 + p(t(:,4),3).*xy412);
g(4,1,:) = -(p(t(:,1),1).*yz123 + p(t(:,1),2).*xz123 + p(t(:,1),3).*xy123);
g(1,2,:) = yz234;
g(2,2,:) = yz341;
g(3,2,:) = yz412;
g(4,2,:) = yz123;
g(1,3,:) = xz234;
g(2,3,:) = xz341;
g(3,3,:) = xz412;
g(4,3,:) = xz123;
g(1,4,:) = xy234;
g(2,4,:) = xy341;
g(3,4,:) = xy412;
g(4,4,:) = xy123;

det=p(t(:,1),1).*yz234+p(t(:,2),1).*yz341 ... ;
   +p(t(:,3),1).*yz412+p(t(:,4),1).*yz123;
vol36 = (0.5)./(6.*det); %  1/(36*volume) = 1/(6*determinant);
vol   = 1./vol36; vol=vol/36; 
vol=0.5*vol; vol36=1./(vol*36);

Al=zeros(4,4,nt); Bl=Al;
for j=1:4;
  for i=1:4;
    tmp=(g(i,2,:).*g(j,2,:)+g(i,3,:).*g(j,3,:)+g(i,4,:).*g(j,4,:));
    tmp=reshape(tmp,nt,1,1);
    Al(i,j,:)=tmp.*vol36;
  end;
  Bl(j,j,:)=vol/4;
end;

nl=4*nt;

%% AL = spalloc(nl,nl,4*nl); BL=AL;
%  for e=0:nt-1;                      %%%% WAY TOO SLOW
%     AL(4*e+(1:4),4*e+(1:4)) = Al(:,:,e+1);
%     BL(4*e+(1:4),4*e+(1:4)) = Bl(:,:,e+1);
%  %  A=full(Al(:,:,e+1)), pause
%  end;

for ipass=1:2;

   d0=zeros(4,nt);        % main diagonal
   d1=zeros(4,nt);        % 1st lower diagonal
   d2=zeros(4,nt);        % 2nd lower diagonal
   d3=zeros(4,nt);        % 2nd lower diagonal

   d0(1,:)=Al(1,1,:);
   d0(2,:)=Al(2,2,:);
   d0(3,:)=Al(3,3,:);
   d0(4,:)=Al(4,4,:);     d0=reshape(d0,nl,1);
   d1(1,:)=Al(2,1,:);
   d1(2,:)=Al(3,2,:);
   d1(3,:)=Al(4,3,:);     d1=reshape(d1,nl,1);
   d2(1,:)=Al(3,1,:);
   d2(2,:)=Al(4,2,:);     d2=reshape(d2,nl,1);
   d3(1,:)=Al(4,1,:);     d3=reshape(d3,nl,1);

   if ipass==1;
      AL=spdiags([d3 d2 d1],-3:-1,nl,nl);
      AL=AL+AL';
      Ad=spdiags(d0,0:0,nl,nl);
      AL=AL+Ad;
   else
      BL=spdiags([d3 d2 d1],-3:-1,nl,nl);
      BL=BL+BL';
      Bd=spdiags(d0,0:0,nl,nl);
      BL=BL+Bd;
   end;

   Al = Bl;

end;

Q  = sparse(1:nl,reshape(t',nl,1),1);
