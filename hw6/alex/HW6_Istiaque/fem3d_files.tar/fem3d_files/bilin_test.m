hdr

L=300;
r=rand(L,1); r = -1 + 2*r;
s=rand(L,1); s = -1 + 2*s;

Hr=[.5*(1-r) .5*(1+r)];
Hs=[.5*(1-s) .5*(1+s)];

u=[ 0 0 ; 0 5 ];

Ur=Hr*u;

U=zeros(L,1);

for l=1:L;
   U(l) = Ur(l,:)*Hs(l,:)';
end;

plot3(r,s,U,'ro',r,s,0*U,'kx',lw,2)


J=zeros(L,4);

for l=1:L;
   J(l,1) = Hr(l,1)*Hs(l,1);
   J(l,2) = Hr(l,2)*Hs(l,1);
   J(l,3) = Hr(l,1)*Hs(l,2);
   J(l,4) = Hr(l,2)*Hs(l,2);
end;

u=reshape(u,4,1);
Ju=J*u;

plot3(r,s,U,'ro',r,s,0*U,'kx',r,s,Ju,'g.',lw,2)




