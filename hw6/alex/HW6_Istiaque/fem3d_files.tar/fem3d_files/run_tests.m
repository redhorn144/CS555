  use_cg=1; i2lev=1;
    icase=icase+1; two_lev_d; result(icase,:)=[n E nref iter etime n^.33333]

  use_cg=1; i2lev=0;
    icase=icase+1; two_lev_d; result(icase,:)=[n E nref iter etime n^.33333]

  use_cg=0; i2lev=0;
    icase=icase+1; two_lev_d; result(icase,:)=[n E nref iter etime n^.33333]
