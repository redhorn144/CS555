function z = mprec(r)

%  global L
%  z = L' \ (L \ r);

   global i2lev
   global dA
   global Jc
   global Ac
   global Lc
   global Lci

   z = dA.*r;

if i2lev > 0
%  z = z + Jc*(Ac\(Jc'*r));  % J is the coarse-to-fine interpolator
%  z = z + Jc*(Lci'*(Lci*(Jc'*r)));  % Jc is the coarse-to-fine interpolator
   z = z + Jc*(Lc'\(Lc\(Jc'*r)));  % Jc is the coarse-to-fine interpolator
end;

end
