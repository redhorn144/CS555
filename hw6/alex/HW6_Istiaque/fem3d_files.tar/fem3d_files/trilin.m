function J=trilin(r,s,t);  %% trilinear interpolation matrix 
                           %% for [r,s]\in[-1,1]^2

Hr=[.5*(1-r) .5*(1+r)];
Hs=[.5*(1-s) .5*(1+s)];
Ht=[.5*(1-t) .5*(1+t)];

L=length(r);
J=zeros(L,8);


   J(:,1) = Hr(:,1).*Hs(:,1).*Ht(:,1);
   J(:,2) = Hr(:,2).*Hs(:,1).*Ht(:,1);
   J(:,3) = Hr(:,1).*Hs(:,2).*Ht(:,1);
   J(:,4) = Hr(:,2).*Hs(:,2).*Ht(:,1);

   J(:,5) = Hr(:,1).*Hs(:,1).*Ht(:,2);
   J(:,6) = Hr(:,2).*Hs(:,1).*Ht(:,2);
   J(:,7) = Hr(:,1).*Hs(:,2).*Ht(:,2);
   J(:,8) = Hr(:,2).*Hs(:,2).*Ht(:,2);

%  
%  for l=1:L;
%  
%     J(l,1) = Hr(l,1).*Hs(l,1).*Ht(l,1);
%     J(l,2) = Hr(l,2).*Hs(l,1).*Ht(l,1);
%     J(l,3) = Hr(l,1).*Hs(l,2).*Ht(l,1);
%     J(l,4) = Hr(l,2).*Hs(l,2).*Ht(l,1);
%  
%     J(l,5) = Hr(l,1).*Hs(l,1).*Ht(l,2);
%     J(l,6) = Hr(l,2).*Hs(l,1).*Ht(l,2);
%     J(l,7) = Hr(l,1).*Hs(l,2).*Ht(l,2);
%     J(l,8) = Hr(l,2).*Hs(l,2).*Ht(l,2);
%  
%  end;
%  
