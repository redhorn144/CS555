function J=bilin(r,s);  %% Bilinear interpolation matrix for [r,s]\in[-1,1]^2

Hr=[.5*(1-r) .5*(1+r)];
Hs=[.5*(1-s) .5*(1+s)];

L=length(r);
J=zeros(L,4);

for l=1:L;
   J(l,1) = Hr(l,1)*Hs(l,1);
   J(l,2) = Hr(l,2)*Hs(l,1);
   J(l,3) = Hr(l,1)*Hs(l,2);
   J(l,4) = Hr(l,2)*Hs(l,2);
end;

