nlast=0;
Nxlast=0;
iperm=0;
icase=0;

result=zeros(1,6);

nref=2, Nx= 2, run_tests;
nref=3, Nx= 5, run_tests;
nref=4, Nx= 8, run_tests;
nref=5, Nx=11, run_tests;
nref=6, Nx=11, run_tests;
nref=7, Nx=11, run_tests;
