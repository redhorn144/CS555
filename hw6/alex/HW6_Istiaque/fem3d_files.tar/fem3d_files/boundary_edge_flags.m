function bedge = boundary_edge_flags(t,Eu)
  % Identify boundary faces: faces appearing only once.
  F = [t(:,[1 2 3]);
       t(:,[1 2 4]);
       t(:,[1 3 4]);
       t(:,[2 3 4])];

  Fs = sort(F,2);
  [Fu,~,icf] = unique(Fs,'rows');
  counts = accumarray(icf,1);

  bfaces = Fu(counts == 1,:);

  % Boundary edges are edges belonging to boundary faces
  BE = [bfaces(:,[1 2]);
        bfaces(:,[1 3]);
        bfaces(:,[2 3])];
  BE = unique(sort(BE,2),'rows');

  % Mark which unique mesh edges are boundary edges
  bedge = ismember(Eu,BE,'rows');
