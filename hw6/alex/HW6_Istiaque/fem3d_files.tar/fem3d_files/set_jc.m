function [Ac,Jc]=set_jc(A,xo,yo,zo,NX,NY,NZ);

%% Set coarse grid solver

NX1=NX+1;
NY1=NY+1;
NZ1=NZ+1;

nc=NX1*NY1*NZ1;  %% BCs built in
n = size(A,1);


Jc=zeros(n,nc);
xc=zeros(nc,1);
yc=zeros(nc,1);
zc=zeros(nc,1);

xomin=1.05*min(min(xo)); xomax=1.05*max(max(xo));
yomin=1.05*min(min(yo)); yomax=1.05*max(max(yo));
zomin=1.05*min(min(zo)); zomax=1.05*max(max(zo));
dx=(xomax-xomin)/NX;
dy=(yomax-yomin)/NY;
dz=(zomax-zomin)/NZ;

L=0; for K=1:NZ; for J=1:NY; for I=1:NX;  L=L+1;
   x0=xomin + dx*(I-1); x1=x0+dx; xom=x0; xM=x1;
   y0=yomin + dy*(J-1); y1=y0+dy; yom=y0; yM=y1;
   z0=zomin + dz*(K-1); z1=z0+dz; zom=z0; zM=z1;
   if I==1; xom=x0-.1*dx; end;  if I==NX; xM=x1+.1*dx; end;
   if J==1; yom=y0-.1*dy; end;  if J==NY; yM=y1+.1*dy; end;
   if K==1; zom=z0-.1*dz; end;  if K==NZ; zM=z1+.1*dz; end;
   ij=find( (xom <= xo & xo < xM) & ...
            (yom <= yo & yo < yM) & ...
            (zom <= zo & zo < zM) ); %% Partition based on orig xyz

   xl=xo(ij); yl=yo(ij); zl=zo(ij);
   rl=-1 + 2*(xl-x0)/(x1-x0);
   sl=-1 + 2*(yl-y0)/(y1-y0);
   tl=-1 + 2*(zl-z0)/(z1-z0);

   Jl=trilin(rl,sl,tl);

   jcol=0; for kk=0:1; for jj=0:1; for ii=0:1;  jcol=jcol+1;
       indx=1 + (I-1+ii)+NX1*(J-1+jj)+NX1*NY1*(K-1+kk);
       Jc(ij,indx)=Jl(:,jcol);
       xc(indx)=x0+dx*ii;
       yc(indx)=y0+dy*jj;
       zc(indx)=z0+dz*kk;
   end; end; end;
end; end; end;

Jc=sparse(Jc);

keep = any(Jc ~= 0, 1);   % logical mask of nonzero columns
Jc   = Jc(:, keep);

Ac = Jc'*A*Jc;

