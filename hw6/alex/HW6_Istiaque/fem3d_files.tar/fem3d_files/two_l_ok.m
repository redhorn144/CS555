hdr;

%lobal L;
global dA;
global i2lev;
global Jc;
global Ac;
global Lc;
global Lci;


nref = 7; 
nref = 5; 
nref = 4; 

if nref ~= nlast;
  gen_sph;
  [AL,BL,Q]=abq_tet(p,t); % Build 3D FEM stiffness matrix
  nlast = nref;

  Ab = Q'*AL*Q;

  nL = 4*E;
  nb = size(Ab,1);

  xb=p(:,1); yb=p(:,2); zb=p(:,3); rb=sqrt(xb.*xb+yb.*yb+zb.*zb);


  ibdry = find(rb>1.0-1e-6);
  R = restriction(ibdry,nb);

  x=R*xb; y=R*yb; z=R*zb; %% Interior points only (for coarse solve)

  yL=Q*yb;
  fL= yL;
  f = R*(Q'*fL);

  A = R*Ab*R';

  n = size(A,1);


% L = ichol(A);

  dA = 1./diag(A);

  if nref < 6;
    lam_max  = eigs(A,1,'lm');
    lam_min  = eigs(A,1,0);
    cond_est = lam_max / lam_min;
    A_eigs   = [ n lam_min lam_max cond_est n^(2/3)]
  end;

end;


%Nx=11
[Ac,Jc]=set_jc(A,x,y,z,Nx,Nx,Nx);


use_cg = 1 
iperm  = 1 
i2lev  = 1 

if iperm > 1;
   nc  = size(Ac,1);
   pc  = symamd(Ac);
   Acp = Ac(pc,pc);
   Lc  = chol(Acp,'lower');
   Jc  = Jc(:,pc);
%  Lci= inv(Lc);
else;
   Lc = chol(Ac,'lower');
%  Lci= inv(Lc);
end;


disp('Start solve.')
t0=tic;
if use_cg > 0;
   tol = 1.e-8; maxit=1000;
   [u, flag, relres, iter, resvec] = pcg(A, f, tol, maxit, @mprec);
   iter
   etime=toc(t0)
else
   u = A \ f;
   etime=toc(t0)
end;
disp('End solve.')
ub= R'*u;

iz=find(abs(zb)<0.02);
um=max(max(abs(ub(iz))));

plot3(xb(iz),yb(iz),ub(iz)/um,'b.',ms,12);
axis equal;

E  = size(t,1);
nb = size(p,1);
title(['Number of Elements and Points, time: ' num2str([E,nb,etime]) ],fs,14);

