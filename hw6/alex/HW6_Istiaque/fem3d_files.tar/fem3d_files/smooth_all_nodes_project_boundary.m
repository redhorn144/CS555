function p = smooth_all_nodes_project_boundary(p,t,niter)

  if nargin < 3
    niter = 5;
  end

  npts = size(p,1);

  E = [t(:,[1 2]);
       t(:,[1 3]);
       t(:,[1 4]);
       t(:,[2 3]);
       t(:,[2 4]);
       t(:,[3 4])];

  E = unique(sort(E,2),'rows');

  A = sparse(E(:,1),E(:,2),1,npts,npts);
  A = A + A';

  deg = sum(A,2);

  r = sqrt(sum(p.^2,2));
  is_bdy = abs(r - 1) < 1e-10;

  for it = 1:niter
    pavg = A*p;
    pavg(:,1) = pavg(:,1) ./ deg;
    pavg(:,2) = pavg(:,2) ./ deg;
    pavg(:,3) = pavg(:,3) ./ deg;

    p = pavg;

    % Re-project boundary nodes to sphere
    rb = sqrt(sum(p(is_bdy,:).^2,2));
    p(is_bdy,:) = p(is_bdy,:) ./ rb;
  end
end
